#!/usr/bin/env bash

python3 calc_emp_exp.py $@