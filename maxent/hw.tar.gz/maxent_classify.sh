#!/usr/bin/env bash

python3 maxent_classify.py $@