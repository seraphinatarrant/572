#!/bin/sh
python /dropbox/17-18/572/check_hw.py /dropbox/17-18/572/languages /dropbox/17-18/572/hw4/submit-file-list hw.tar.gz
