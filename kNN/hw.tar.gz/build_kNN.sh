#!/usr/bin/env bash

python3 build_kNN.py $@