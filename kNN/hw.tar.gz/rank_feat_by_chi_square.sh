#!/usr/bin/env bash

python3 rank_feat_by_chi_square.py $@