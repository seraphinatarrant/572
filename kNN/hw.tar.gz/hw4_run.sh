#!/usr/bin/env bash

time ./build_kNN.sh examples/train.vectors.txt examples/test.vectors.txt 1 1 sys_output_1_1 > acc_file_1_1
time ./build_kNN.sh examples/train.vectors.txt examples/test.vectors.txt 5 1 sys_output_5_1 > acc_file_5_1
time ./build_kNN.sh examples/train.vectors.txt examples/test.vectors.txt 10 1 sys_output_10_1 > acc_file_10_1

time ./build_kNN.sh examples/train.vectors.txt examples/test.vectors.txt 1 2 sys_output_1_2 > acc_file_1_2
time ./build_kNN.sh examples/train.vectors.txt examples/test.vectors.txt 5 2 sys_output > acc_file
time ./build_kNN.sh examples/train.vectors.txt examples/test.vectors.txt 10 2 sys_output_10_2 > acc_file_10_2

cat examples/train.vectors.txt | ./rank_feat_by_chi_square.sh > feat_list