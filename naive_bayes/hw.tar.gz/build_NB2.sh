#!/bin/sh

python3 build_NB2.py $@