#!/bin/sh

python3 build_NB1.py $@